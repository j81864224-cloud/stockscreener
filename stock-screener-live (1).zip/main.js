// main.js
// IMPORTANT: Replace PROXY_URL with your deployed worker URL.
// e.g. const PROXY_URL = "https://your-worker.yourdomain.workers.dev";
const PROXY_URL = "REPLACE_WITH_YOUR_PROXY_URL";

const builtInStocks = [
  "AAPL","MSFT","GOOGL","AMZN","NVDA","TSLA","JPM","XOM","V","META",
  "BABA","INTC","NFLX","CRM","PYPL","ADBE","ORCL","CSCO","NKE","DIS"
];

let stocks = []; // will store live data

const tbody = document.getElementById('stockBody');
const searchEl = document.getElementById('search');
const sectorFilter = document.getElementById('sectorFilter');
const capFilter = document.getElementById('capFilter');
const priceFilter = document.getElementById('priceFilter');
const refreshBtn = document.getElementById('refreshBtn');
const loading = document.getElementById('loading');
const headers = document.querySelectorAll('thead th');

function fmtCap(n){
  if(!n) return '';
  if(n>=1e12) return (n/1e12).toFixed(2)+'T';
  if(n>=1e9) return (n/1e9).toFixed(2)+'B';
  if(n>=1e6) return (n/1e6).toFixed(2)+'M';
  return n.toString();
}

function render(){
  const q = searchEl.value.trim().toLowerCase();
  let filtered = stocks.filter(s=>{
    if(!s || !s.symbol) return false;
    const matchSearch = s.symbol.toLowerCase().includes(q) || (s.shortName && s.shortName.toLowerCase().includes(q));
    if(!matchSearch) return false;
    if(sectorFilter.value && s.sector && sectorFilter.value !== s.sector) return false;
    if(capFilter.value){
      const cap = s.marketCap || 0;
      if(capFilter.value === 'mega' && cap < 200e9) return false;
      if(capFilter.value === 'large' && (cap < 10e9 || cap >= 200e9)) return false;
      if(capFilter.value === 'mid' && (cap < 2e9 || cap >= 10e9)) return false;
      if(capFilter.value === 'small' && cap >= 2e9) return false;
    }
    if(priceFilter.value){
      const p = s.regularMarketPrice || 0;
      if(priceFilter.value==='p1' && p>=20) return false;
      if(priceFilter.value==='p2' && (p<20||p>100)) return false;
      if(priceFilter.value==='p3' && (p<100||p>500)) return false;
      if(priceFilter.value==='p4' && p<=500) return false;
    }
    return true;
  });

  tbody.innerHTML = '';
  filtered.forEach(s=>{
    const tr = document.createElement('tr');
    const change = s.regularMarketChangePercent ? s.regularMarketChangePercent.toFixed(2) : '';
    tr.innerHTML = `
      <td>${s.symbol||''}</td>
      <td>${s.shortName||''}</td>
      <td>${s.regularMarketPrice!==undefined? s.regularMarketPrice.toFixed(2): ''}</td>
      <td>${fmtCap(s.marketCap)}</td>
      <td>${s.sector||''}</td>
      <td>${change}</td>
    `;
    tbody.appendChild(tr);
  });
}

function populateSectors(){
  const sectors = Array.from(new Set(stocks.map(s=>s.sector).filter(Boolean))).sort();
  sectorFilter.innerHTML = '<option value="">All sectors</option>';
  sectors.forEach(sec=>{
    const o = document.createElement('option'); o.value = sec; o.textContent = sec; sectorFilter.appendChild(o);
  });
}

async function fetchQuotes(symbols){
  if(!PROXY_URL || PROXY_URL.startsWith('REPLACE')) {
    alert('Please deploy the included worker and set PROXY_URL at the top of main.js to its URL.');
    return [];
  }
  loading.style.display = 'inline';
  try{
    const res = await fetch(`${PROXY_URL}/quote?symbols=${symbols.join(',')}`);
    if(!res.ok) throw new Error('Proxy error: '+res.status);
    const data = await res.json();
    // Yahoo response path: data.quoteResponse.result
    return data.quoteResponse && data.quoteResponse.result ? data.quoteResponse.result : [];
  }catch(err){
    console.error(err);
    alert('Failed to fetch quotes. See console for details.');
    return [];
  }finally{
    loading.style.display = 'none';
  }
}

async function refreshAll(){
  // fetch in batches (Yahoo supports many at once, but keep batches small)
  const batchSize = 10;
  let results = [];
  for(let i=0;i<builtInStocks.length;i+=batchSize){
    const batch = builtInStocks.slice(i,i+batchSize);
    const r = await fetchQuotes(batch);
    results = results.concat(r);
  }
  // Merge results into stocks array, keeping sector if missing
  stocks = results.map(r=>{
    return {
      symbol: r.symbol,
      shortName: r.shortName,
      regularMarketPrice: r.regularMarketPrice,
      marketCap: r.marketCap,
      sector: r.sector || r.industry || ''
    };
  });
  populateSectors();
  render();
}

refreshBtn.addEventListener('click', refreshAll);
searchEl.addEventListener('input', render);
sectorFilter.addEventListener('change', render);
capFilter.addEventListener('change', render);
priceFilter.addEventListener('change', render);

// Sorting
headers.forEach(h=>{
  h.addEventListener('click', ()=>{
    const key = h.dataset.key;
    if(!key) return;
    stocks.sort((a,b)=>{
      const va = a[key]||0, vb = b[key]||0;
      return vb - va;
    });
    render();
  });
});

// initial empty render
render();
