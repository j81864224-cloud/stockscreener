// worker.js - Cloudflare Worker to proxy Yahoo Finance quote endpoint
// Deploy this on Cloudflare Workers (free). It fetches Yahoo and returns JSON to the browser.
// NOTE: Yahoo unofficial endpoints can change. This worker simply forwards the request server-side
// which avoids CORS problems. If you get blocked, consider using a paid market data API.

addEventListener('fetch', event => {
  event.respondWith(handle(event.request));
});

async function handle(request) {
  const url = new URL(request.url);
  if (url.pathname === '/quote') {
    const symbols = url.searchParams.get('symbols') || '';
    // Basic validation
    if (!symbols) {
      return new Response(JSON.stringify({error: 'symbols param required'}), {status:400, headers: {'Content-Type': 'application/json'}});
    }
    // Construct Yahoo Finance endpoint
    const yahooUrl = 'https://query1.finance.yahoo.com/v7/finance/quote?symbols=' + encodeURIComponent(symbols);
    try {
      const resp = await fetch(yahooUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0',
          'Accept': 'application/json'
        }
      });
      const text = await resp.text();
      // Return raw body and headers
      return new Response(text, {
        status: resp.status,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET,HEAD,POST,OPTIONS',
        }
      });
    } catch (err) {
      return new Response(JSON.stringify({error: 'fetch failed', detail: err.message}), {status:500, headers: {'Content-Type':'application/json'}});
    }
  }

  // For OPTIONS preflight
  if (request.method === 'OPTIONS') {
    return new Response(null, {status:204, headers: {'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'GET,HEAD,POST,OPTIONS'}});
  }

  return new Response(JSON.stringify({msg: 'ok'}), {headers: {'Content-Type':'application/json'}});
}
