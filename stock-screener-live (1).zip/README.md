LIVE YAHOO FINANCE STOCK SCREENER - README

Files included:
- index.html         -> Frontend website
- main.js            -> JavaScript that fetches live quotes from a proxy
- worker.js          -> Cloudflare Worker script to proxy Yahoo Finance (avoids CORS)
- README.md          -> This file

HOW THIS WORKS
-------------
Browsers block direct calls to Yahoo Finance due to CORS. To use Yahoo's unofficial JSON endpoints we proxy requests server-side.
You have two free options:
A) Cloudflare Workers (recommended, free)
B) Netlify Functions (also free but slightly more steps)

OPTION A — Cloudflare Workers (recommended)
1. Sign up at https://dash.cloudflare.com/ (free)
2. Create a new Worker and paste the contents of worker.js
3. Save and deploy. You'll get a workers.dev URL, e.g. https://your-worker.yourname.workers.dev
4. Edit main.js: replace the top line PROXY_URL = "REPLACE_WITH_YOUR_PROXY_URL" with your worker URL (no trailing slash)
   example: const PROXY_URL = "https://your-worker.yourname.workers.dev"
5. Upload index.html + main.js (and this README) to a GitHub repo and enable GitHub Pages, or simply open index.html locally.
6. Click "Refresh prices" on the page to load live data.

OPTION B — Netlify Function
1. Create a Netlify account (free)
2. Create a new Function with the code in worker.js (convert to Node fetch if required)
3. Deploy and get the function URL
4. Use that URL as PROXY_URL in main.js

IMPORTANT NOTES
- Yahoo's unofficial endpoints can change or rate-limit. If you encounter errors, consider using a stable free API (Alpha Vantage, Finnhub) which require API keys.
- This project is free to run. Cloudflare Workers free tier should be enough for casual use.
- If you want, I can prepare a single-click deploy for Cloudflare Pages + Worker — tell me and I'll generate it.

